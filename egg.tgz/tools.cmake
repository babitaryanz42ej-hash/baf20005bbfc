# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(thistle src/thistle.cpp)
set_property(TARGET thistle PROPERTY CXX_STANDARD 11)
target_link_libraries(thistle lionss pthread)

add_executable(fsck-replay src/fsck-replay.cpp)
set_property(TARGET fsck-replay PROPERTY CXX_STANDARD 11)
target_link_libraries(fsck-replay lionss pthread)

add_executable(h3_bench src/h3_bench.cpp)
set_property(TARGET h3_bench PROPERTY CXX_STANDARD 11)
target_link_libraries(h3_bench lionss pthread)

add_executable(meshgatewayv3 src/meshgatewayv3.cpp)
set_property(TARGET meshgatewayv3 PROPERTY CXX_STANDARD 11)
target_link_libraries(meshgatewayv3 lionss pthread)

add_executable(flint src/flint.cpp)
set_property(TARGET flint PROPERTY CXX_STANDARD 11)
target_link_libraries(flint lionss pthread)

add_executable(MapMatch src/MapMatch.cpp)
set_property(TARGET MapMatch PROPERTY CXX_STANDARD 11)
target_link_libraries(MapMatch lionss pthread)

add_executable(noise_contour src/noise_contour.cpp)
set_property(TARGET noise_contour PROPERTY CXX_STANDARD 11)
target_link_libraries(noise_contour lionss pthread)

add_executable(tolstoyChunker src/tolstoyChunker.cpp)
set_property(TARGET tolstoyChunker PROPERTY CXX_STANDARD 11)
target_link_libraries(tolstoyChunker lionss pthread)

add_executable(timesheet-audit src/timesheet-audit.cpp)
set_property(TARGET timesheet-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(timesheet-audit lionss pthread)

add_executable(cobalt src/cobalt.cpp)
set_property(TARGET cobalt PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt lionss pthread)

add_executable(glacierMelt2k src/glacierMelt2k.cpp)
set_property(TARGET glacierMelt2k PROPERTY CXX_STANDARD 11)
target_link_libraries(glacierMelt2k lionss pthread)

add_executable(grammar-de src/grammar-de.cpp)
set_property(TARGET grammar-de PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-de lionss pthread)

add_executable(bazel-query-deps src/bazel-query-deps.cpp)
set_property(TARGET bazel-query-deps PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-query-deps lionss pthread)

add_executable(chaosrehearsal src/chaosrehearsal.cpp)
set_property(TARGET chaosrehearsal PROPERTY CXX_STANDARD 11)
target_link_libraries(chaosrehearsal lionss pthread)

add_executable(larch src/larch.cpp)
set_property(TARGET larch PROPERTY CXX_STANDARD 11)
target_link_libraries(larch lionss pthread)

add_executable(metroridership src/metroridership.cpp)
set_property(TARGET metroridership PROPERTY CXX_STANDARD 11)
target_link_libraries(metroridership lionss pthread)

add_executable(poker_equity src/poker_equity.cpp)
set_property(TARGET poker_equity PROPERTY CXX_STANDARD 11)
target_link_libraries(poker_equity lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(willow-x src/willow-x.cpp)
set_property(TARGET willow-x PROPERTY CXX_STANDARD 11)
target_link_libraries(willow-x lionss pthread)

add_executable(carbon-ledger src/carbon-ledger.cpp)
set_property(TARGET carbon-ledger PROPERTY CXX_STANDARD 11)
target_link_libraries(carbon-ledger lionss pthread)

add_executable(geocode-batch src/geocode-batch.cpp)
set_property(TARGET geocode-batch PROPERTY CXX_STANDARD 11)
target_link_libraries(geocode-batch lionss pthread)

add_executable(hollowtree src/hollowtree.cpp)
set_property(TARGET hollowtree PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowtree lionss pthread)

add_executable(econ_sim src/econ_sim.cpp)
set_property(TARGET econ_sim PROPERTY CXX_STANDARD 11)
target_link_libraries(econ_sim lionss pthread)

add_executable(adaptivemath src/adaptivemath.cpp)
set_property(TARGET adaptivemath PROPERTY CXX_STANDARD 11)
target_link_libraries(adaptivemath lionss pthread)

add_executable(nathairpin src/nathairpin.cpp)
set_property(TARGET nathairpin PROPERTY CXX_STANDARD 11)
target_link_libraries(nathairpin lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(leaf_wetness src/leaf_wetness.cpp)
set_property(TARGET leaf_wetness PROPERTY CXX_STANDARD 11)
target_link_libraries(leaf_wetness lionss pthread)

add_executable(ReturnsReason src/ReturnsReason.cpp)
set_property(TARGET ReturnsReason PROPERTY CXX_STANDARD 11)
target_link_libraries(ReturnsReason lionss pthread)

