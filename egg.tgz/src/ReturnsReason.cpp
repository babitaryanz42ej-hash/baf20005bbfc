// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cluster reasons"); }
int main(){
  announce();
  return lionss_run_workload("ReturnsReason");
}
