// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("IRT item selection for 50 learners\n", stdout);
  return lionss_run_workload("adaptivemath");
}
