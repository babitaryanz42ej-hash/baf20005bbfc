// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Monthly scope-1/2 totals"); }
int main(){
  announce();
  return lionss_run_workload("carbon-ledger");
}
