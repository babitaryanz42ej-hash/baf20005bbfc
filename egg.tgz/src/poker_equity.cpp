// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Monte Carlo equity, 1M trials"); }
int main(){
  announce();
  return lionss_run_workload("poker_equity");
}
