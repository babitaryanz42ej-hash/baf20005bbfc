// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Replay journal and check inodes"); }
int main(){
  announce();
  return lionss_run_workload("fsck-replay");
}
