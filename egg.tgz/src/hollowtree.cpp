// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Convert to grade-2 braille");
  std::fflush(stdout);
  return lionss_run_workload("hollowtree");
}
