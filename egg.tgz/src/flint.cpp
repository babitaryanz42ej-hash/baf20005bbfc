// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Filter QUAL<30 and depth"); }
int main(){
  announce();
  return lionss_run_workload("flint");
}
