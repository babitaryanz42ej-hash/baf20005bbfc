// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Forward geocode\n", stdout);
  return lionss_run_workload("geocode-batch");
}
