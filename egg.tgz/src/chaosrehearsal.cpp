// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Inject latency, 5 min"); }
int main(){
  announce();
  return lionss_run_workload("chaosrehearsal");
}
