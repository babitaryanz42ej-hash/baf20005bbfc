// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Overtime and break compliance\n", stdout);
  return lionss_run_workload("timesheet-audit");
}
