// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Train DQN, 2M frames"); }
int main(){
  announce();
  return lionss_run_workload("MsPacmanRl");
}
