// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Trim and stability check\n", stdout);
  return lionss_run_workload("ballast-calc");
}
