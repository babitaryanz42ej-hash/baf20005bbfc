// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Annual mass balance step"); }
int main(){
  announce();
  return lionss_run_workload("glacierMelt2k");
}
