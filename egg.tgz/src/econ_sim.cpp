// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("500 ticks of supply-demand"); }
int main(){
  announce();
  return lionss_run_workload("econ_sim");
}
