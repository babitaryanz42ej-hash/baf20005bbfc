// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Chunk into 512-token windows"); }
int main(){
  announce();
  return lionss_run_workload("tolstoyChunker");
}
